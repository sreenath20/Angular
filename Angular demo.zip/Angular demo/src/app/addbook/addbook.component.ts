import { Component, OnInit } from '@angular/core';
import { Book } from '../book';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {

  book: Book;
  constructor() { }

  ngOnInit() {
  }

}
