import { Component, OnInit } from '@angular/core';
import { BookService } from '../book.service';
import { Book, Employee, Department } from '../book';

@Component({
  selector: 'app-viewbook',
  templateUrl: './viewbook.component.html',
  styleUrls: ['./viewbook.component.css']
})
export class ViewbookComponent implements OnInit {
  books: Book[] = [];
  emp:Employee;
  dept:Department;
  info:string;
  errorInfo:string;

  constructor(private bookService: BookService) { }

  ngOnInit() {
    console.log("inside ngOninit viewbook component");
    this.bookService.loadBooks().subscribe(data => {
      this.books = data;
      //this.bookService.setBooks(this.books);
    });


    this.bookService.loadEmp().subscribe(data => {
      this.emp = data;
      this.dept=data.department;//same as emp.department;
      //this.bookService.setBooks(this.books);
    });

}

}
