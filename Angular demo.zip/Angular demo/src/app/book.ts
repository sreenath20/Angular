export class Book {
  id : number;
  bookName:string;
  author:string;
  cost:number;  
}

export class Department {
  id : number;
  name:string;
  created_at:Date;  
}
export class Employee {
  id : number;
  name:string;
  salary:number;
  cost:number;  
  department:Department;
}

